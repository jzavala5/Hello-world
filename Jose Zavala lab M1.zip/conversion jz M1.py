# Jose Zavala
# 1/16/2020
# This is to learn how to use python
# converts km to mph 
# I'm not sure how to use this program yet, so giving tips isn't there yet. 
#!/usr/bin/env python
kmh = int(input("Enter km/h: "))
mph =  0.6214 * kmh
print("Speed:", kmh, "KM/H = ", mph, "MPH")
"Enter km/h: 55 "
