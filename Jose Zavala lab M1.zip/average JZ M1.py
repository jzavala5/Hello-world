# Jose Zavala
# 1/16/2020
# This is to learn how to get the average for 3 numbers
# Gets the aveage for 3 numbers, can change this to handle more numbers later.
# This program is for math, very fast and good to use.
#!/usr/bin/env python
round1 = int(input("Enter score for round 1: "))
round2 = int(input("Enter score for round 2: "))
round3 = int(input("Enter score for round 3: "))
average = (round1 + round2 + round3) / 3
print ("the average score is: ", average)
5
2
5
