#Jose Zavala
#1/30/2020

#This program is to convert Fahrenheit to degrees celsius 

#Problem 7

#first start with labling what is what
input= ("what is F")

F=("what is F")
F= (F-32)

#F+F-32

#F=F*9

#F=F/5
