#Jose Zavala
#1/30/2020

#This Program is to ask for a name and greets them.

#Problem 2


myName = input("what is your name ")

print("It is nice to meet you, "+ myName)
