#Jose Zavala
#1/30/2020

#This program is find the MPG for car 

#Problem 6
#get miles and gallons, make sure That it in order. 
miles=input("give me a number")
X=int(miles)
#Make sure miles is a different interger 
gallon=input("give me a number")
Y=int(gallon)
#Make sure Gallon is a different interger 

answer =(X/Y)
#Make sure you use the right equation for this problem, which is miles/gallon
print (answer)

print ("Good job!")

