#Jose Zavala
#1/30/2020

#This program is to greet more then one person

#Problem 3

myName = input("what is your name ")

if myName=="Robyn":
    #stuff to do if it's Robyn
    print("Hey Robyn")

else:
    #Stuff to do if you're not Robyn
    print ("Locked out")

#print("It is nice to meet you, "+ myName)
