Python 3.8.1 (tags/v3.8.1:1b293b6, Dec 18 2019, 22:39:24) [MSC v.1916 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
>>> 3*3
9
>>> print "hello world"
SyntaxError: Missing parentheses in call to 'print'. Did you mean print("hello world")?
>>> print "Hello world"
SyntaxError: Missing parentheses in call to 'print'. Did you mean print("Hello world")?
>>> Print ("Hello world")
Traceback (most recent call last):
  File "<pyshell#4>", line 1, in <module>
    Print ("Hello world")
NameError: name 'Print' is not defined
>>> print 'Hello world'
SyntaxError: Missing parentheses in call to 'print'. Did you mean print('Hello world')?
>>> yes
Traceback (most recent call last):
  File "<pyshell#6>", line 1, in <module>
    yes
NameError: name 'yes' is not defined
>>> print ("Hello world!")
Hello world!
>>> 
=========== RESTART: C:/Users/CSIS/Desktop/P1 Hello world JZ.py ==========
Hello world!
>>> 
=========== RESTART: C:/Users/CSIS/Desktop/P1 Hello world JZ.py ==========
Hello world!
>>> 
============= RESTART: C:/Users/CSIS/Desktop/P2 Hey you JZ.py ============
what is your name?

============= RESTART: C:/Users/CSIS/Desktop/P2 Hey you JZ.py ============
what is your name?
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P2 Hey you JZ.py", line 10, in <module>
    myName = input(Jose)
NameError: name 'Jose' is not defined
>>> 
============= RESTART: C:/Users/CSIS/Desktop/P2 Hey you JZ.py ============
what is your name?
Jose
============= RESTART: C:/Users/CSIS/Desktop/P2 Hey you JZ.py ============
what is your name?
Jose
============= RESTART: C:/Users/CSIS/Desktop/P2 Hey you JZ.py ============
what is your name?
Jose
============= RESTART: C:/Users/CSIS/Desktop/P2 Hey you JZ.py ============
what is your name?
Jose
============= RESTART: C:/Users/CSIS/Desktop/P2 Hey you JZ.py ============
what is your name?
Jose
============= RESTART: C:/Users/CSIS/Desktop/P2 Hey you JZ.py ============
what is your name?
Jose
============= RESTART: C:/Users/CSIS/Desktop/P2 Hey you JZ.py ============
what is your name?
Jose1254
It is nice to meet you, 1254
>>> 
============= RESTART: C:/Users/CSIS/Desktop/P2 Hey you JZ.py ============
what is your name Jose 
It is nice to meet you,  Jose 
>>> 
============= RESTART: C:/Users/CSIS/Desktop/P2 Hey you JZ.py ============
what is your name jose
It is nice to meet you, jose
>>> 
========== RESTART: C:/Users/CSIS/Desktop/P3 Robyn or Not JZ.py ==========
what is your name Jose
Locked out
It is nice to meet you, Jose
>>> 
========== RESTART: C:/Users/CSIS/Desktop/P3 Robyn or Not JZ.py ==========
what is your name Robyn
Hey Robyn
It is nice to meet you, Robyn
>>> 
========== RESTART: C:/Users/CSIS/Desktop/P3 Robyn or Not JZ.py ==========
what is your name jose
Locked out
>>> 
========== RESTART: C:/Users/CSIS/Desktop/P3 Robyn or Not JZ.py ==========
what is your name Robyn
Hey Robyn
>>> 
=========== RESTART: C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py ==========
what is the area of the cirle, if the radius is 2
>>> 2
2
>>> 2*2
4
>>> 
=========== RESTART: C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py ==========
X1
>>> 
=========== RESTART: C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py ==========
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py", line 8, in <module>
    input (X)
NameError: name 'X' is not defined
>>> 
=========== RESTART: C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py ==========
radius2
>>> 
=========== RESTART: C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py ==========
radius2
>>> 
=========== RESTART: C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py ==========
radius3
>>> 
=========== RESTART: C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py ==========
radius2
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py", line 12, in <module>
    input=X
NameError: name 'X' is not defined
>>> 
=========== RESTART: C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py ==========
radius2
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py", line 12, in <module>
    input =X
NameError: name 'X' is not defined
>>> 
=========== RESTART: C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py ==========
radius2
>>> 2
2
>>> 
=========== RESTART: C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py ==========
please input a radius2
>>> 
=========== RESTART: C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py ==========
please input a radius2
>>> 
=========== RESTART: C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py ==========
please input a radius2
<built-in function input>
>>> 
=========== RESTART: C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py ==========
please input a radius2
2
>>> 2^2
0
>>> 
=========== RESTART: C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py ==========
please input a radius2
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py", line 11, in <module>
    print (X)
NameError: name 'X' is not defined
>>> 
=========== RESTART: C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py ==========
please input a radius2
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py", line 11, in <module>
    print (X)
NameError: name 'X' is not defined
>>> 
=========== RESTART: C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py ==========
please input a radius2
2
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py", line 13, in <module>
    Radius=(Radius *Radius)
TypeError: can't multiply sequence by non-int of type 'str'
>>> 
=========== RESTART: C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py ==========
please input a radius2
2
>>> 
=========== RESTART: C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py ==========
please input a radius2
what is the answer
2
>>> 
=========== RESTART: C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py ==========
please input a radius2
2
>>> 
=========== RESTART: C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py ==========
please input a radius2
2
12.56
>>> 
=========== RESTART: C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py ==========
please input a radius5
5
78.5
>>> 
=========== RESTART: C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py ==========
please input a radius12
12
452.15999999999997
>>> 
=========== RESTART: C:/Users/CSIS/Desktop/P5 CIrcle area JZ.py ==========
please input a radius2
2
12.56
Nice job!
>>> 
======== RESTART: C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py ========
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py", line 9, in <module>
    answer = (miles/gallons)
NameError: name 'miles' is not defined
>>> 
======== RESTART: C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py ========
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py", line 7, in <module>
    int(input = ("miles used"))
TypeError: 'input' is an invalid keyword argument for int()
>>> 
======== RESTART: C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py ========
give me a number24
give me a number12
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py", line 12, in <module>
    answer = (miles/gallons)
NameError: name 'gallons' is not defined
>>> 
======== RESTART: C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py ========
give me a number24
give me a number12
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py", line 12, in <module>
    answer = (miles/gallon)
TypeError: unsupported operand type(s) for /: 'str' and 'str'
>>> 
======== RESTART: C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py ========
give me a number24
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py", line 8, in <module>
    int(miles=input("give me a number"))
TypeError: 'miles' is an invalid keyword argument for int()
>>> 
======== RESTART: C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py ========
give me a number24
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py", line 9, in <module>
    int(miles=input)
TypeError: 'miles' is an invalid keyword argument for int()
>>> 
======== RESTART: C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py ========
give me a number24
give me a number12
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py", line 14, in <module>
    answer = (miles/gallon)
TypeError: unsupported operand type(s) for /: 'str' and 'str'
>>> 
======== RESTART: C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py ========
give me a number24
24
give me a number12
12
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py", line 14, in <module>
    answer = (miles/gallon)
TypeError: unsupported operand type(s) for /: 'str' and 'str'
>>> 
======== RESTART: C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py ========
give me a number24
give me a number12
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py", line 14, in <module>
    answer = (miles/gallon)
TypeError: unsupported operand type(s) for /: 'str' and 'str'
>>> 
======== RESTART: C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py ========
give me a number24
give me a number12
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py", line 14, in <module>
    answer = (miles/gallon)
TypeError: unsupported operand type(s) for /: 'str' and 'str'
>>> 
======== RESTART: C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py ========
give me a number24
give me a number12
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py", line 14, in <module>
    answer =(miles/gallon)
TypeError: unsupported operand type(s) for /: 'str' and 'str'
>>> 
======== RESTART: C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py ========
give me a number24
give me a number12
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py", line 15, in <module>
    answer =(miles/gallon)
TypeError: unsupported operand type(s) for /: 'str' and 'str'
>>> 
======== RESTART: C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py ========
give me a number24
give me a number12
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py", line 13, in <module>
    x/gallon
NameError: name 'x' is not defined
>>> 
======== RESTART: C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py ========
give me a number24
give me a number12
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py", line 13, in <module>
    x=x/gallon
NameError: name 'x' is not defined
>>> 
======== RESTART: C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py ========
give me a number24
give me a number12
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py", line 13, in <module>
    X=x/gallon
NameError: name 'x' is not defined
>>> 
======== RESTART: C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py ========
give me a number24
give me a number12
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py", line 13, in <module>
    X=X/gallon
TypeError: unsupported operand type(s) for /: 'str' and 'str'
>>> 
======== RESTART: C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py ========
give me a number24
give me a number12
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py", line 15, in <module>
    answer =(miles/gallon)
TypeError: unsupported operand type(s) for /: 'str' and 'str'
>>> 
======== RESTART: C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py ========
give me a number24
give me a number12
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py", line 15, in <module>
    answer =(miles/gallon)
TypeError: unsupported operand type(s) for /: 'str' and 'str'
>>> 
======== RESTART: C:/Users/CSIS/Desktop/P6 miles per Gallon JZ.py ========
give me a number24
give me a number12
2.0
Good job!
>>> 
=============== RESTART: C:/Users/CSIS/Desktop/P7 F-C JZ.py ==============
>>> 
=============== RESTART: C:/Users/CSIS/Desktop/P7 F-C JZ.py ==============
Traceback (most recent call last):
  File "C:/Users/CSIS/Desktop/P7 F-C JZ.py", line 12, in <module>
    F= (F-32)
TypeError: unsupported operand type(s) for -: 'str' and 'int'
>>> 