#Jose Zavala
#1/30/2020

#This program is to Find the radius of a Circle, a math problem

#Problem 5
#This is for radius of the circle
Radius= int(input ("please input a radius"))

 #This is for how big is the radius.

print(Radius)

answer=(3.14*Radius*Radius)
print(answer)

print ("Nice job!")
